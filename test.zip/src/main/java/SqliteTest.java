import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class SqliteTest {
    public static void main( String args[] ) throws IOException {
        Connection c = null;
        Statement stmt = null;
        BigDecimal total = BigDecimal.ZERO;
        File file = new File("err.txt");
        FileWriter w = new FileWriter(file);
        try {
            Class.forName("org.sqlite.JDBC");

            while (true) {
                String dbname = "t" + new Date().getTime() + ".db";
                c = DriverManager.getConnection("jdbc:sqlite:" + dbname);
                c.setAutoCommit(false);
                System.out.println("Opened database successfully");

                stmt = c.createStatement();
                String sql = "CREATE TABLE COMPANY " +
                        "(amount         numberic)";
                stmt.executeUpdate(sql);

                total = BigDecimal.ZERO;
                for (int i = 0; i < 3000000; i++) {
                    double r = Math.round(Math.random() * 100000) / 100.0;
                    String t = r + "";
                    BigDecimal amount = new BigDecimal(t).setScale(2);
                    sql = "INSERT INTO COMPANY (amount) " +
                            "VALUES (" + amount + ");";
                    stmt.executeUpdate(sql);
                    total = total.add(amount);
                }

                String sum = "0";
                ResultSet rs = stmt.executeQuery("SELECT sum(cast(amount * 1000 as real)) / 1000.0 's' FROM COMPANY;");
                while (rs.next()) {
                    sum = rs.getString("s");
                    System.out.println("sum = " + sum);
                    System.out.println();
                }

                stmt.close();
                c.commit();
                c.close();

                if (total.compareTo(new BigDecimal(sum)) != 0) {
                    w.write(dbname + "|sum=" + sum + "|total=" + total + "\r\n");
                    w.flush();
                } else {
                    File dbFile = new File(dbname);
                    if (dbFile.exists()) {
                        boolean delete = dbFile.delete();
                    }
                }
                System.out.println(dbname + "|sum=" + sum + "|total=" + total + "\r\n");
                Thread.sleep(10000);
            }
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            e.printStackTrace();
            System.exit(0);
        }
    }
}
